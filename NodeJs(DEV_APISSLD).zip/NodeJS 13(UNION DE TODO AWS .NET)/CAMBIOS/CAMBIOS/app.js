﻿'use strict';
const moment = require('moment-timezone');

exports.handler = async (event) => {
    let responseCode = 200;
    let Json;
    let data;
    let datoant;
    let datoant2;
    let Valor;
    let n = 0;
    let r;

    const fechaHoraActual = moment().tz('America/Santiago').format('YYYY-MM-DD HH:mm:ss').slice(0, 19).replace("T", " ");
    //console.log("request: " + JSON.stringify(event));

    // AUTORIZACIONES
    process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = '0';
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

    require('request').defaults({ rejectUnauthorized: false });
    require('request').defaults({ d: { LogonByNameUser: false } });
    if (event.body) {

        let body = JSON.parse(event.body);

        const urlRecibida = body.URL;
        const Account = body.username;
        const Password = body.password;

        // METODO POST DE LOGIN
        const axios = require('axios');
        const UrlSap = urlRecibida + '/LogonByNamedUser';
        const FullUrl = urlRecibida + '/Tenants';
        const URL6 = urlRecibida + '/APIGatewayServices';
        const FullUrl2 = urlRecibida + '/Extensions';


        axios.get(urlRecibida)
            .then((response) => {
                const statusCode = response.status;
                console.log('Status Code:', statusCode);

                // VALIDACIÓN Credenciales
                if ((!body.username || !body.password)) {
                    const errorResponse = {
                        statusCode: 401,
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({ error: "JSON inválido, propiedades faltantes o valores incorrectos en el usuario o contraseña" })
                    };
                    console.error("JSON inválido, propiedades faltantes o valores incorrectos en el usuario o contraseña");
                    return errorResponse;
                }
            })
            .catch((error) => {
                console.error('Error:', error);
            });



        // CONEXIÓN EN LA BASE DE DATOS
        const mysql = require('mysql');
        const Conexion = mysql.createConnection({
            host: 'mysqltest.crocguuvud3j.us-east-1.rds.amazonaws.com',
            user: 'admin',
            password: 'DyAHFc4md8SFGcrNZNit',
            database: 'DB_COMPANY',
            port: 3306
        });

        const queryPromise = (query, values) => {
            return new Promise((resolve, reject) => {
                Conexion.query(query, values, (error, results, fields) => {
                    if (error) {
                        reject(error);
                    } else {
                        resolve(results);
                    }
                });
            });
        };

        const truncateTables = async () => {
            try {
                await queryPromise("DELETE FROM Mailer");
                await queryPromise("DELETE FROM APIGatewayServices");
                await queryPromise("DELETE FROM Tenant");
                await queryPromise("DELETE FROM ServiceUnit");
                await queryPromise("DELETE FROM  Extensions");
                await queryPromise("DELETE FROM  B1ServiceLayers");

                console.log("Tablas vaciadas con éxito");
            } catch (error) {
                console.error("Error al vaciar las tablas: ", error);
            }
        };



        const conexionPromise = new Promise((resolve, reject) => {
            Conexion.connect((err) => {
                if (err) {
                    console.error('Error en la conexión: ', err);
                    reject(err);
                } else {
                    truncateTables();
                    
                    // POST
                    data = {
                        https_port: 443,
                        Account: Account,
                        Password: Password
                    };

                    let separacion;
                    let datos;

                    axios.post(UrlSap, data)

                        .then(function (response) {
                            separacion = response;
                            datos = response.headers['set-cookie'][0].split(';')[0];

                            // GET
                            return axios.get(FullUrl, {
                                headers: {
                                    'Cookie': datos
                                }
                            });

                        })
                        .then(async (response) => {
                            const results = response.data.d.results;
                            const IDS = results.map(authorizacion => authorizacion.ID);
                            const URL6 = urlRecibida + `/APIGatewayServices`;
                            const FullUrl2 = urlRecibida + '/Extensions';

                            const promises = IDS.map(async (id) => {
                                const URL = urlRecibida + `/Tenants('${id}')/CompanyDatabase`;
                                const URL2 = urlRecibida + `/Tenants('${id}')/ServiceUnit`;

                                const [
                                    responseCompanyDatabase,
                                    responseServiceUnit
                                ] = await Promise.all([
                                    axios.get(URL, { headers: { 'Cookie': datos } }),
                                    axios.get(URL2, { headers: { 'Cookie': datos } })
                                ]);


                                // Corroboración de Datos CompanyDatabase
                                const valoresCompanyDatabase = {
                                    Status: responseCompanyDatabase.data.d.CompanyStatus,
                                    Name: responseCompanyDatabase.data.d.Name,
                                    Version: responseCompanyDatabase.data.d.Version,
                                    IdTenants: id,
                                    Mode: responseCompanyDatabase.data.d.mode,
                                    Localization: responseCompanyDatabase.data.d.Localization,
                                    CompanyName: responseCompanyDatabase.data.d.CompanyName
                                };

                                // Corroboración de Datos ServiceUnit
                                const valoresServiceUnit = {
                                    Status: responseServiceUnit.data.d.Status,
                                    Name: responseServiceUnit.data.d.Name,
                                    Version: responseServiceUnit.data.d.Version,
                                    IdServiceUnits: responseServiceUnit.data.d.ID,
                                    URL: urlRecibida

                                };
                                const URL5 = urlRecibida + `/ServiceUnits('${responseServiceUnit.data.d.ID}')/Mailer`;

                                n += 1;

                                if (n == IDS.length) {
                                    const [
                                        responseMailer,
                                        responseAPIGatewayServices,

                                    ] = await Promise.all([
                                        axios.get(URL5, { headers: { 'Cookie': datos } }),
                                        axios.get(URL6, { headers: { 'Cookie': datos } }),

                                    ]);


                                    // Corroboración de Datos Mailer
                                    const valoresMailer = {
                                        Status: responseMailer.data.d.Status,
                                        Name: responseMailer.data.d.Name,
                                        ServerType: responseMailer.data.d.ServerType,
                                        IdMailer: responseMailer.data.d.ID

                                    };

                                    //  Corroboración de Datos APIGatewayServices
                                    const valoresAPIGatewayServices = {
                                        Status: responseAPIGatewayServices.data.d.results[0].Status,
                                        Name: responseAPIGatewayServices.data.d.results[0].Name,
                                        IdAPIGS: responseAPIGatewayServices.data.d.results[0].ID,
                                        URL: urlRecibida
                                    };
                                    try {

                                        await Promise.all([
                                            queryPromise(`INSERT INTO Mailer (Status, Name, ServerType, IdMailer, URL, Fecha_Ult_Act) VALUES (?, ?, ?, ?, ?, ?)`, [valoresMailer.Status, valoresMailer.Name, valoresMailer.ServerType, valoresMailer.IdMailer, urlRecibida, fechaHoraActual]),
                                            queryPromise(`INSERT INTO APIGatewayServices(Status, Name, IdAPIGS, URL, Fecha_Ult_Act) VALUES(?, ?, ?, ?, ?)`, [valoresAPIGatewayServices.Status, valoresAPIGatewayServices.Name, valoresAPIGatewayServices.IdAPIGS, valoresAPIGatewayServices.URL, fechaHoraActual]),
                                            queryPromise(`INSERT INTO ServiceUnit (Status, Name, Version, URL, Fecha_Ult_Act) VALUES (?, ?, ?, ?, ?)`, [valoresServiceUnit.Status, valoresServiceUnit.Name, valoresServiceUnit.Version, valoresServiceUnit.URL, fechaHoraActual])
                                        ]);
                                    } catch (error) {
                                        console.error('ERROR al insertar datos : ', error);
                                    }

                                }
                                // AGREGA LOS DATOS A SU RESPECTIVA BASE DE DATOS
                                try {

                                    await Promise.all([
                                        queryPromise(`INSERT INTO Tenant (Status, Name, Version, IdTenants, URL, Fecha_Ult_Act) VALUES (?, ?, ?, ?, ?, ?)`, [valoresCompanyDatabase.Status, valoresCompanyDatabase.Name, valoresCompanyDatabase.Version, id, urlRecibida, fechaHoraActual]),

                                    ]);

                                } catch (error) {
                                    console.error('ERROR al insertar datos : ', error);
                                }
                            });
                            Promise.all(promises)
                                .then(() => {
                                    resolve('Inserciones completadas con éxito');
                                })
                                .catch((error) => {
                                    console.error('Error en el procesamiento de datos: ', error);
                                    reject(error);
                                });
                        })
                        .catch(function (error) {
                            console.log(error);
                            reject(error);
                        });

                    axios.post(UrlSap, data)
                        .then(function (response) {
                            separacion = response;
                            datos = response.headers['set-cookie'][0].split(';')[0];
                            //GET
                            return axios.get(FullUrl, {
                                headers: {
                                    'Cookie': datos
                                }
                            })
                        })

                        //B1ServiceLayer

                        .then(response => {
                            const results = response.data.d.results;
                            const IDS = results.map(authorizacion => authorizacion.ID);


                            for (let i = 0; i < IDS.length; i++) {
                                const URL = urlRecibida + `/Tenants('${IDS[i]}')/ServiceUnit`;
                                axios.get(URL, {
                                    headers: {
                                        'Cookie': datos
                                    }
                                })
                                    .then(function (response) {
                                        const URL2 = urlRecibida + `/ServiceUnits('${response.data.d.ID}')/B1ServiceLayers`;
                                        axios.get(URL2, {
                                            headers: {
                                                'Cookie': datos
                                            }
                                        })



                                        //Corroboración de datos antes de ingresarlo a la BASE de Datos
                                        const valoresB1ServiceLayers = {
                                            Status: response.data.d.Status,
                                            Name: response.data.d.Name,
                                            URL: urlRecibida

                                        };

                                        //console.log(Valor);


                                        if (i == IDS.length - 1) {
                                            //console.log(Valor);
                                            //AGREGANDO VALORES EN LAS COLUMNAS
                                            const fechaHoraActual = moment().tz('America/Santiago').format('YYYY-MM-DD HH:mm:ss');
                                            const Agregar = `INSERT INTO B1ServiceLayers (Status, Name, URL, Fecha_Ult_Act) VALUES ('${valoresB1ServiceLayers.Status}','${valoresB1ServiceLayers.Name}','${valoresB1ServiceLayers.URL}','${fechaHoraActual}')`;

                                            //CORROBORANDO QUE SE HAYAN INGRESADO LOS DATOS

                                            Conexion.query(Agregar, (err, result) => {

                                                if (err) {
                                                    console.error('No se han AGREGADO los datos yyyy', err);
                                                    return;
                                                }
                                                console.log('Se a AGREGADO con exito los reesultados');
                                            });

                                        }


                                    })
                                    .catch(function (error) {
                                        console.log(error);
                                    })
                            }
                        })
                        .catch(function (error) {
                            console.log(error);
                        });

                    //Extensions

                    axios.post(UrlSap, data)
                        .then(function (response) {
                            separacion = response;
                            datos = response.headers['set-cookie'][0].split(';')[0];
                            return axios.get(FullUrl2, {
                                headers: {
                                    'Cookie': datos
                                }
                            });
                        })
                        .then(async response => {
                            const results = response.data.d.results;
                            const IDS = results.map(authorizacion => authorizacion.ID);

                            const promises2 = IDS.map(async (id) => {
                                const URL2 = urlRecibida + `/Extensions('${id}')`;

                                try {
                                    const response = await axios.get(URL2, {
                                        headers: {
                                            'Cookie': datos
                                        }
                                    });
                                    //Revisión de datos, antes de ingresarlos a la BASE de DATOS
                                    const Valores = {
                                        Type: response.data.d.Type,
                                        Version: response.data.d.Version,
                                        Vendor: response.data.d.Vendor,
                                        Name: response.data.d.Name,
                                        IdExtensions: id,
                                        URL: urlRecibida

                                    };
                                    //console.log(Valores);
                                    const fechaHoraActual = moment().tz('America/Santiago').format('YYYY-MM-DD HH:mm:ss');
                                    //AGREGANDO VALORES EN LAS COLUMNAS
                                    const Agregar2 = `INSERT INTO Extensions (Type, Version, Vendor, Name, IdExtensions, URL, Fecha_Ult_Act ) VALUES ('${response.data.d.Type}', '${response.data.d.Version}','${response.data.d.Vendor}','${response.data.d.Name}', '${id}', '${urlRecibida}','${fechaHoraActual}' )`

                                    //CORROBORANDO QUE SE HAYAN INGRESADO LOS DATOS

                                    Conexion.query(Agregar2, (err, result) => {

                                        if (err) {
                                            console.error('No se han AGREGADO los datohhhhhs', err);
                                            return;
                                        }
                                        console.log('Se a AGREGADO con exito los resultados');
                                    });


                                } catch (error) {
                                    console.log(error);
                                }
                            });

                            await Promise.all(promises2);
                        })
                        .catch(function (error) {
                            console.log(error);
                        });
                }


            });

        });


        try {
            const resultado = await conexionPromise;

            if (responseCode == 200) {
                let response = {
                    statusCode: responseCode,
                    headers: {
                        "cookie1": "valorcookie1",
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(resultado)
                };
                console.log("response: " + JSON.stringify(response));
                return response;
            } else {
                let response = {
                    statusCode: responseCode,
                    headers: {
                        "cookie1": "valorcookie1",
                        "Content-Type": "application/json"
                    },
                    body: "ERROR CON EL CONTENIDO STATUS  " + responseCode
                };
                console.log("response: " + JSON.stringify(response));
                return response;
            }
        } catch (error) {
            const errorResponse = {
                statusCode: 500,
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ error: "ERROR en la conexión" })
            };
            console.error("ERROR en la conexión: ", error);
            return errorResponse;
        }
    }
    else {
        console.log("No hay JSON");
        const errorResponse = {
            statusCode: 400,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ error: "No se recibió ningún JSON" })
        };
        return errorResponse;
    }
};